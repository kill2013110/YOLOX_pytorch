#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# Copyright (c) Megvii Inc. All rights reserved.

import torch
import torch.nn as nn


class IOUloss(nn.Module):
    def __init__(self, reduction="none", loss_type="alpha_ciou"):
        super(IOUloss, self).__init__()
        self.reduction = reduction
        self.loss_type = loss_type

    def forward(self, pred, target):
        assert pred.shape[0] == target.shape[0]

        pred = pred.view(-1, 4)
        '''cx,cy,w,h'''
        target = target.view(-1, 4)
        tl = torch.max(
            (pred[:, :2] - pred[:, 2:] / 2), (target[:, :2] - target[:, 2:] / 2)
        )
        br = torch.min(
            (pred[:, :2] + pred[:, 2:] / 2), (target[:, :2] + target[:, 2:] / 2)
        )

        area_p = torch.prod(pred[:, 2:], 1)
        area_g = torch.prod(target[:, 2:], 1)

        en = (tl < br).type(tl.type()).prod(dim=1)
        area_i = torch.prod(br - tl, 1) * en
        area_u = area_p + area_g - area_i
        iou = (area_i) / (area_u + 1e-16)

        if self.loss_type == "iou":
            loss = 1 - iou
            # loss = 1 - iou*iou
            # return iou
        elif self.loss_type == "giou":
            c_tl = torch.min(
                (pred[:, :2] - pred[:, 2:] / 2), (target[:, :2] - target[:, 2:] / 2)
            )
            c_br = torch.max(
                (pred[:, :2] + pred[:, 2:] / 2), (target[:, :2] + target[:, 2:] / 2)
            )
            area_c = torch.prod(c_br - c_tl, 1)
            giou = iou - (area_c - area_u) / area_c.clamp(1e-16)
            loss = 1 - giou.clamp(min=-1.0, max=1.0)
        elif self.loss_type == "alpha_ciou":
            alpha_power = 2

            epsilon = torch.tensor(1e-07)

            b1_xy = pred[..., :2]
            b1_wh = pred[..., 2:4]
            b1_wh_half = b1_wh / 2.
            b1_mins = b1_xy - b1_wh_half
            b1_maxes = b1_xy + b1_wh_half

            b2_xy = target[..., :2]
            b2_wh = target[..., 2:4]
            b2_wh_half = b2_wh / 2.
            b2_mins = b2_xy - b2_wh_half
            b2_maxes = b2_xy + b2_wh_half

            center_distance = torch.sum(torch.square(b1_xy - b2_xy), axis=-1)
            enclose_mins = torch.minimum(b1_mins, b2_mins)
            enclose_maxes = torch.maximum(b1_maxes, b2_maxes)
            enclose_wh = torch.maximum(enclose_maxes - enclose_mins, torch.tensor(0.0))
            # -----------------------------------------------------------#
            #   计算对角线距离
            #   enclose_diagonal (batch, feat_w, feat_h, anchor_num)
            # -----------------------------------------------------------#
            enclose_diagonal = torch.sum(torch.square(enclose_wh), axis=-1)

            R_d = 1.0 * (center_distance) / torch.maximum(enclose_diagonal,  epsilon)

            v = 4 * torch.square(torch.atan2(b1_wh[..., 0], torch.maximum(b1_wh[..., 1], epsilon))- torch.atan2(b2_wh[..., 0],torch.maximum(b2_wh[..., 1], epsilon)))/(torch.pi * torch.pi)
            beta = v / torch.maximum((1.0 - iou + v), epsilon)

            # ciou = ciou - beta * v

            loss = 1 - torch.pow(iou, alpha_power) + torch.pow(R_d, alpha_power) +torch.pow(beta*v, alpha_power)
            #
            # return ciou
        if self.reduction == "mean":
            loss = loss.mean()
        elif self.reduction == "sum":
            loss = loss.sum()

        return loss

if __name__ == "__main__":
    import numpy as np

    pred = torch.tensor(np.load('pred_np.npy'))
    target = torch.tensor(np.load('target_np.npy'))

    iou = IOUloss(reduction="none")
    giou= IOUloss(loss_type="giou")
    a_ciou=IOUloss(loss_type="alpha_ciou")

    b0 = torch.tensor([125, 125, 50, 50], dtype=torch.float32)
    b1 = torch.tensor([65, 65, 30, 30], dtype=torch.float32)
    b2 = torch.tensor([85, 115, 30, 30], dtype=torch.float32)
    b3 = torch.tensor([115, 115, 30, 30], dtype=torch.float32)
    b4 = torch.tensor([115, 125, 30, 30], dtype=torch.float32)
    b5 = torch.tensor([125, 125, 18, 50], dtype=torch.float32)
    b6 = torch.tensor([125, 125, 30, 30], dtype=torch.float32)

    x = [b1, b2,b3,b4, b5, b6]
    for i in x:
        print('\n')
        print(iou.forward(i, b0))
        print(a_ciou.forward(i, b0))
    print()

    print(iou.forward(pred, target))
    print(a_ciou.forward(pred, target))
    iou.forward(pred, target)


