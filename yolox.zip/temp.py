import torch


print(torch.nn.Sigmoid()(-0.7))